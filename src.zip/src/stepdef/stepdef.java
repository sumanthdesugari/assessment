package stepdef;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepdef {
	WebDriver driver;   //creating a driver
	@Given("^Registration wesite$")
	public void registration_wesite() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\jarlib\\BDD Jar Files\\chromedriver_win32\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("C:\\Users\\saisvank\\Desktop\\SET02\\RegistrationForm.html");
		driver.manage().window().maximize();  //to maximize the window
		
	}

	@When("^user inputs valid credentials$")
	public void user_inputs_valid_credentials() throws Throwable {
	    String title=driver.getTitle();  //getting title
	    if(title.equalsIgnoreCase("Welcome to JobsWorld")) {System.out.println("Title-NoDefect");}
	    else {System.out.println("Title-Defect");}
	    
	    
	    //finding and sending  userid
	    driver.findElement(By.id("usrID")).sendKeys("sa12");
	    driver.findElement(By.id("pwd")).submit();
	    Alert idalert=driver.switchTo().alert();
	    System.out.println( idalert.getText());
	    Thread.sleep(1000);
	    idalert.accept();
	    driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	    driver.findElement(By.id("usrID")).clear();
	    driver.findElement(By.id("usrID")).sendKeys("saisuresh12");
	    
	    
	    //finding and sending password
	    
	    driver.findElement(By.id("pwd")).sendKeys("pa!1");
	    driver.findElement(By.id("usrname")).submit();
	    Alert passwordalert=driver.switchTo().alert();
		System.out.println( passwordalert.getText());
		Thread.sleep(1000);
		passwordalert.accept();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.findElement(By.id("pwd")).clear();
		driver.findElement(By.id("pwd")).sendKeys("password");
		
		
		
		//finding and sending username
		
		driver.findElement(By.id("usrname")).sendKeys("123");
		driver.findElement(By.id("addr")).submit();
		Alert namealert=driver.switchTo().alert();
	
		System.out.println(namealert.getText());
		Thread.sleep(1000);
		namealert.accept();
		
		
		
		  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		  driver.findElement(By.id("usrname")).clear();
		  driver.findElement(By.id("usrname")).sendKeys("vankasaisuresh");
		  
		  
		  
		  //finding and sending address
		driver.findElement(By.id("addr")).sendKeys("adress=12");
		driver.findElement(By.name("country")).submit();
		Alert addressalert=driver.switchTo().alert();
		
		System.out.println(addressalert.getText());
		Thread.sleep(1000);
		addressalert.accept();
		
		  driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		  driver.findElement(By.id("addr")).clear();
		  driver.findElement(By.id("addr")).sendKeys("Hyderabad");	
		  
		
		  
		  
		  //finding and selecting countries
		Select select=new Select(driver.findElement(By.name("country")));
		
		driver.findElement(By.name("zip")).submit();
		Alert selectalert=driver.switchTo().alert();
		System.out.println(selectalert.getText());
		Thread.sleep(1000);
		selectalert.accept();
		
			
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 select.selectByVisibleText("India");
		 
		 
		 //finding and sending zipcode
		 driver.findElement(By.name("zip")).sendKeys("abcd");
		 driver.findElement(By.name("email")).submit();
		 Alert zipalert=driver.switchTo().alert();
		 System.out.println(zipalert.getText());
		 Thread.sleep(1000);
		 zipalert.accept();
		 
		 
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.name("zip")).clear();
		 driver.findElement(By.name("zip")).sendKeys("560037");
		 
		 
		 
		 //finding and sending email
		 driver.findElement(By.name("email")).sendKeys("abc");
		 driver.findElement(By.name("sex")).submit();
		 Alert emailalert=driver.switchTo().alert();
		 System.out.println(emailalert.getText());
		 Thread.sleep(1000);
		 emailalert.accept();
		 
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		 driver.findElement(By.name("email")).clear();
		 driver.findElement(By.name("email")).sendKeys("saisuresh@cg.com");
		 
		 
		 //finding and selecting gender
		List list=driver.findElements(By.name("sex"));
		driver.findElement(By.id("desc")).submit();
		 Alert genderalert=driver.switchTo().alert();
		 System.out.println(genderalert.getText());
		Thread.sleep(1000);
		 genderalert.accept();
		 
		 driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		((WebElement) list.get(0)).click();
		 
		 //finding and sending about details
		
		driver.findElement(By.id("desc")).sendKeys("A sports freak!!");
		
		driver.findElement(By.name("submit")).submit();
		System.out.println("submitted the form");
	    
		
		
	}

	@Then("^user should be Register$")
	public void user_should_be_Register() throws Throwable {
	   
		//registered message
		System.out.println("User registration done successfully!! ");
	}


}
