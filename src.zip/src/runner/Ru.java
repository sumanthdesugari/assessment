package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Assessment\\173631_VankaSaiSuresh\\src\\scenario-feature\\cg.feature"},//giving the feature file path
		glue="stepdef",     //for connecting to stepdef java file
		plugin= {"pretty","html:target/cg-report"},	//report is stored in cg-report
		monochrome=true,		//inorder to get homogeneous output
		dryRun=true				//inorder to get the overridden methods of feature file
		)


public class Ru {

}
